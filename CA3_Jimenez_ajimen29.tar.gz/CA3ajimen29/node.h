#include <string>

using namespace std;

class Node{
	public:
	Node();

	Node *next;
	string element;

	private:

};
