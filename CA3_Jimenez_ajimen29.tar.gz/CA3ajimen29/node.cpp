#include <string>
#include <stdlib.h>
#include "node.h"

using namespace std;

Node::Node(){
	next=NULL;
	element="";
}
