#include <string>
#include <iostream>
#include <stdlib.h>
#include <typeinfo>
#include "llc.h"
#include <cmath>
#include <ctgmath>

using namespace std;

LLC::LLC(){
	tailNode = NULL;
	headNode = NULL;
}

LLC::~LLC(){
	Node *current = headNode;
	while(current!=NULL){
		Node *next = current->next;
		delete current;
		current = next;
	}
}

LLC::LLC(const LLC &obj){
	tailNode=NULL;
	headNode=NULL;
	Node *traverser = obj.headNode;
	while(traverser!=NULL){
		string el = traverser->element;
		insert(el);
		traverser=traverser->next;
	}
}

void LLC::operator=(LLC const &obj){
	Node *current = headNode;
	while(current!=NULL){
		Node *next = current->next;
		delete current;
		current = next;
	}
	Node *traverser = obj.headNode;
	while(traverser!=NULL){
		insert(traverser->element);
		traverser=traverser->next;
	}
}

void LLC::operator+=(int n){
	Node *next=headNode->next;
	int i=0;
	while (i<n && headNode!=NULL){
		insert(headNode->element);
		delete headNode;
		headNode = next;
		next=headNode->next;
		/*Node *temp= new Node();
		temp->element=headNode->element;
		if(tailNode==NULL){
			headNode=temp;
		}else{
			tailNode->next=temp;
		}
		tailNode=temp;*/
		i++;
	}
	//TODO:GET THIS TO WORK
}

bool LLC::insert(const string &data){
	bool tf=false;
	Node *temp= new Node();
	temp->element=data;
	if(tailNode==NULL){
		headNode=temp;
		tf=true;
	}else{
		tailNode->next=temp;
		tf=true;
	}
	tailNode=temp;
	return tf;
}

ostream & operator<<(ostream &out, const LLC &obj){
	Node *temp = obj.headNode;
	if(obj.headNode==NULL){
		out << "This list is empty!";
		return out;
	}
	out << "[";
	while(temp!=NULL){
		out << temp->element << ", ";
		temp = temp->next;
	}
	out << "]";
	return out;
}

int LLC::len(){
	Node *traverser = headNode;
	int size=0;
	while(traverser!=NULL){
		size++;
		traverser=traverser->next;
	}
	return size;
}

bool LLC::contains(const string &check){
	bool tf = false;
	Node *traverser = headNode;
	while(traverser!=NULL){
		if((traverser->element)==check){
			tf=true;
		}
		traverser=traverser->next;
	}
	return tf;
}

void LLC::head(int n){
	Node *traverser = headNode;
	cout << "[";
	int x=1;
	while(traverser!=NULL && x<n+1){
		cout << traverser->element << ", ";
		traverser=traverser->next;
		x++;
	}
	cout << "]";
}

string LLC::tail(){
	return tailNode->element;
}

void LLC::join(LLC other){
	Node *traverser = other.headNode;
	while(traverser!=NULL){
		string el = traverser->element;
		insert(el);
		traverser=traverser->next;
	}
	//tailNode->next=other.headNode;
	//cout <<"headnode next of other: " << other.headNode->next->element; << "tailnode of other: " << other.tailNode->element;
	//tailNode=other.tailNode;
	//cout << tailNode->element;
	//delete other.headNode;
	//delete other.tailNode;
	//TODO:MAKE THIS WORK!
}

void LLC::remove(const string &check){
	Node *prev=headNode;
	Node *current=headNode->next;
	if(headNode==NULL){
		return;
	}else if(prev->element==check){
		headNode->next=current->next;
		headNode=current;
		delete prev;
		prev=headNode;
		current=headNode->next;
	}
	while(current!=NULL){
		if(prev->element==check){
			headNode->next=current->next;
			headNode=current;
			delete prev;
			prev=headNode;
			current=headNode->next;
		}else if(current->element==check){
			prev->next=current->next;
			delete current;
			current=prev->next;
		}
		prev=prev->next;
		current=current->next;
	}
}

void LLC::shuffle(){
	int length = this->len();
	double shufflenum = length / 3;
	int realshuffle = ceil(shufflenum);
	*this+=realshuffle;
}

LLC LLC::operator+(const LLC &obj){
	LLC *newList = new LLC();
	Node *list1 = headNode;
	Node *list2 = obj.headNode;
	while(list1!=NULL){
		string el = list1->element;
		newList->insert(el);
		list1=list1->next;
	}
	while(list2!=NULL){
		string el = list2->element;
		newList->insert(el);
		list2=list2->next;
	}
	return *newList;
}
