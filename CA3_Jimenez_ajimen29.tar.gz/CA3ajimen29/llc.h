#include <iostream>
#include "node.h"
#include <string>

using namespace std;

class LLC{
	public:
	LLC();
	LLC(const LLC &copy);

	void operator=(LLC const &obj);

	LLC operator+(LLC const &obj);

	void operator+=(int n);

	friend ostream & operator<<(ostream &out, const LLC &obj);

	bool contains(const string &check);

 	bool insert(const string &data);

	void remove(const string &data);

	void shuffle();

	void head(int n);

	int len();

	void join(LLC other);

	string tail();

	~LLC();

	Node *headNode;
	Node *tailNode;

	private:

};
