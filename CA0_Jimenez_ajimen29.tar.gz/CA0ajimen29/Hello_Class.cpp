#include "Hello_Class.h"

void Hello_Class::print_hello(){
         cout << output_string << endl;
}
