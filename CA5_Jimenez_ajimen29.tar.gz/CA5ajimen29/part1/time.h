#include <string>

class Time{
	Time(int hh, int mm, string ampm);

	Time compareTimes(t1,t2);

	int hr;
	int min;
	int aftermorn;
}
