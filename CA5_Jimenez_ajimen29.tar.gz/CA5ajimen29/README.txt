To run Any itinerary (part 1 of the assignment) run using ./flight.exe in.txt. The program will prompt you for a departure and arrival city.

Earliest time itinerary (part 2) is not compiling. I attempted to make a vector in each city that would hold every flight time (depature and arrival) as well as the departure and arrival cities (stored as an edge object in each city). I would then follow my itinerary as created by the first part and then parse all edges for the earliest edge past the specified departure time (prompted by program).
